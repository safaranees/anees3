import React from 'react'
class App1 extends React.Component {

    constructor(props) {
      super(props);
      this.state = {
        isLoginOpen: true,
        isRegisterOpen: false
      };
    }
  
    render() {
  
      return (
        <div>
            helloooooooo
        </div>
      );
    }
  }

  export default App1