import React from 'react'

 function About({result}) {
    
    
    
    return (
        <div>
            
            <p>ReactJS is JavaScript library used for building reusable UI components. According to React official documentation, following is the definition − React is a library for building composable user interfaces. It encourages the creation of reusable UI components, which present data that changes over time.</p>
        </div>
    )
}
export default About
