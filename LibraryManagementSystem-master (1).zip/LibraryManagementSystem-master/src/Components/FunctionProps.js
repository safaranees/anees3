import React from 'react'

export default function FunctionProps() {
    return (
        <div>
            <h3>functional property component example</h3>
        </div>
    )
}
