import React from 'react'

function FRInput() {
    return (
        <div>
            
        </div>
    )
}

export default FRInput
